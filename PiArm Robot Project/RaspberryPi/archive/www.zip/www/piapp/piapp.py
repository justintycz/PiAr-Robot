from flask import Flask, render_template, Response, request, redirect, url_for
from flask import render_template, request

app = Flask(__name__)

import serial
import time
import sys

ser = serial.Serial('/dev/ttyACM0', 9600)
ser.flush()

@app.route('/')	
def _main():
	return "<h1>Main Python Server Page</h1><p>Robot Control URL:  192.168.0.47/piapp/robot/</p>"

@app.route('/robot/')	
@app.route('/robot/pos/', methods=(['GET', 'POST']))
def _gui():
	
	if request.method == 'POST':
		request.form['submit']
		
		val = ser.readline()
		val = val.decode()
		val = val.strip() 
		
		if request.form['submit'] == 'Home':
			ser.write(b'0')
		elif request.form['submit'] == 'Pos1':
			ser.write(b'1')
			
	return render_template('robot.html')
	
	time.sleep(1)
	
if __name__ == '__main__':
	app.run()
