document.write("<p>1</p>");
const raspi = require('raspi');
const Serial = require('raspi-serial').Serial;
document.write("<p>2</p>");

raspi.init(() +> {
	
	var serial new Serial();
	serial.open(() +> {
		serial.on('data', (data) => {
			process.stdout.write(data);
		});
		serial.write('Hello');
	});
});
	
